
import streamlit as st

st.set_page_config(page_title="Aplikasi Streamlit GitHub", layout="centered")

st.title("📘 Aplikasi Streamlit Terhubung GitHub")
st.write("Ini adalah contoh aplikasi yang dijalankan langsung dari repositori GitHub.")

st.subheader("🔢 Contoh Input")
angka = st.number_input("Masukkan angka", value=0)
st.write("Kuadrat dari angka tersebut adalah:", angka**2)

st.info("Untuk bantuan lebih lanjut, kunjungi [docs.streamlit.io](https://docs.streamlit.io).")
