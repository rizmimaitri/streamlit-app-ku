
# 📘 Aplikasi Streamlit GitHub

Aplikasi ini dibuat menggunakan [Streamlit](https://streamlit.io) dan disambungkan langsung dengan GitHub.

## 🛠️ Cara Menjalankan

1. Clone repositori ini
2. Install Streamlit:

```bash
pip install -r requirements.txt
```

3. Jalankan aplikasinya:

```bash
streamlit run streamlit_app.py
```

## 🚀 Atau Jalankan Langsung di Streamlit Cloud

Deploy langsung dari GitHub melalui [Streamlit Cloud](https://streamlit.io/cloud).

---
